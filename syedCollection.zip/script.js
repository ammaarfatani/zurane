/* ═══════════════════════════════════════════════════════
   Salman LAHORE — script.js
═══════════════════════════════════════════════════════ */

'use strict';

/* ── Utility ─────────────────────────────────────────── */
const $ = (sel, ctx = document) => ctx.querySelector(sel);
const $$ = (sel, ctx = document) => [...ctx.querySelectorAll(sel)];

/* ── State ───────────────────────────────────────────── */
const state = {
  cart: JSON.parse(localStorage.getItem('Salman_cart') || '[]'),
  wishlist: JSON.parse(localStorage.getItem('Salman_wish') || '[]'),
  heroIndex: 0,
  heroTimer: null,
  announceVisible: true,
};

/* ── Save helpers ────────────────────────────────────── */
function saveCart()     { localStorage.setItem('Salman_cart', JSON.stringify(state.cart)); }
function saveWishlist() { localStorage.setItem('Salman_wish', JSON.stringify(state.wishlist)); }

document.addEventListener("DOMContentLoaded", () => {

const navToggle = document.getElementById("navToggle");
const mobileNav = document.getElementById("mobileNav");
const closeMenu = document.getElementById("closeMenu");
const overlay = document.getElementById("overlay");

console.log(navToggle);

navToggle.addEventListener("click", () => {
    mobileNav.classList.add("open");
    overlay.classList.add("visible");
});

closeMenu.addEventListener("click", () => {
    mobileNav.classList.remove("open");
    overlay.classList.remove("visible");
});

overlay.addEventListener("click", () => {
    mobileNav.classList.remove("open");
    overlay.classList.remove("visible");
});

});

document.querySelectorAll(".has-dropdown").forEach(item => {

    const toggle = item.querySelector(".menu-row");

    toggle.addEventListener("click", () => {

        item.classList.toggle("active");

    });

});
/* ════════════════════════════════════════════════════════
   ANNOUNCEMENT BAR
════════════════════════════════════════════════════════ */
// (function initAnnouncement() {
//   const bar    = $('#announcementBar');
//   const header = $('#header');
//   const closeBtn = $('#closeAnnouncement');
//   if (!bar || !closeBtn) return;

//   closeBtn.addEventListener('click', () => {
//     bar.classList.add('hidden');
//     header.classList.add('announce-gone');
//     state.announceVisible = false;
//     sessionStorage.setItem('Salman_announce', 'closed');
//   });

//   // Restore closed state within session
//   if (sessionStorage.getItem('Salman_announce') === 'closed') {
//     bar.classList.add('hidden');
//     header.classList.add('announce-gone');
//     state.announceVisible = false;
//   }
// })();



/* ════════════════════════════════════════════════════════
   HEADER — sticky + scrolled class
════════════════════════════════════════════════════════ */
(function initHeader() {
  const header = $('#header');
  if (!header) return;

  let lastY = window.scrollY;

  function onScroll() {
    const y = window.scrollY;
    if (y > 50) {
      header.classList.add('scrolled');
    } else {
      header.classList.remove('scrolled');
    }
    lastY = y;
  }

  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();
})();

/* ════════════════════════════════════════════════════════
   SEARCH BAR
════════════════════════════════════════════════════════ */
(function initSearch() {
  const toggle = $('#searchToggle');
  const bar    = $('#searchBar');
  const close  = $('#searchClose');
  const input  = $('#searchInput');
  if (!toggle || !bar) return;

  toggle.addEventListener('click', () => {
    bar.classList.toggle('open');
    if (bar.classList.contains('open')) {
      setTimeout(() => input && input.focus(), 350);
    }
  });

  close && close.addEventListener('click', () => {
    bar.classList.remove('open');
  });

  document.addEventListener('keydown', e => {
    if (e.key === 'Escape') bar.classList.remove('open');
  });
})();

/* ════════════════════════════════════════════════════════
   MOBILE NAV
════════════════════════════════════════════════════════ */
(function initMobileNav() {
  const toggle  = $('#navToggle');
  const nav     = $('#mobileNav');
  const overlay = $('#overlay');
  if (!toggle || !nav) return;

  function openNav() {
    toggle.classList.add('open');
    nav.classList.add('open');
    overlay.classList.add('visible');
    document.body.style.overflow = 'hidden';
  }
  function closeNav() {
    toggle.classList.remove('open');
    nav.classList.remove('open');
    overlay.classList.remove('visible');
    document.body.style.overflow = '';
  }

  toggle.addEventListener('click', () => {
    nav.classList.contains('open') ? closeNav() : openNav();
  });
  overlay.addEventListener('click', closeNav);
  document.addEventListener('keydown', e => e.key === 'Escape' && closeNav());
})();

/* ════════════════════════════════════════════════════════
   HERO SLIDER
════════════════════════════════════════════════════════ */
(function initHeroSlider() {
  const slides = $$('.hero-slide');
  const dots   = $$('.hero-dot');
  const prev   = $('#heroPrev');
  const next   = $('#heroNext');
  if (!slides.length) return;

 function goTo(index) {
  slides[state.heroIndex]?.classList.remove('active');
  dots[state.heroIndex]?.classList.remove('active');

  state.heroIndex = (index + slides.length) % slides.length;

  slides[state.heroIndex]?.classList.add('active');
  dots[state.heroIndex]?.classList.add('active');
}

  function startTimer() {
    clearInterval(state.heroTimer);
    state.heroTimer = setInterval(() => goTo(state.heroIndex + 1), 6000);
  }

  prev && prev.addEventListener('click', () => { goTo(state.heroIndex - 1); startTimer(); });
  next && next.addEventListener('click', () => { goTo(state.heroIndex + 1); startTimer(); });

  dots.forEach((dot, i) => {
    dot.addEventListener('click', () => { goTo(i); startTimer(); });
  });

  // Touch/swipe
  let touchStartX = 0;
  const hero = $('.hero');
  hero && hero.addEventListener('touchstart', e => {
    touchStartX = e.touches[0].clientX;
  }, { passive: true });
  hero && hero.addEventListener('touchend', e => {
    const diff = touchStartX - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) {
      diff > 0 ? goTo(state.heroIndex + 1) : goTo(state.heroIndex - 1);
      startTimer();
    }
  }, { passive: true });

  startTimer();
})();

/* ════════════════════════════════════════════════════════
   CART
════════════════════════════════════════════════════════ */
(function initCart() {
  const drawerToggle = $('#cartToggle');
  const drawer       = $('#cartDrawer');
  const closeBtn     = $('#cartClose');
  const overlay      = $('#overlay');
  const cartCount    = $('#cartCount');
  const continueBtn  = $('#cartContinue');

  function openCart() {
    drawer && drawer.classList.add('open');
    overlay && overlay.classList.add('visible');
    document.body.style.overflow = 'hidden';
  }
  function closeCart() {
    drawer && drawer.classList.remove('open');
    // Only remove overlay if mobile nav is also closed
    if (!$('#mobileNav')?.classList.contains('open')) {
      overlay && overlay.classList.remove('visible');
    }
    document.body.style.overflow = '';
  }

  drawerToggle && drawerToggle.addEventListener('click', openCart);
  closeBtn     && closeBtn.addEventListener('click', closeCart);
  continueBtn  && continueBtn.addEventListener('click', closeCart);
  overlay      && overlay.addEventListener('click', closeCart);

  function updateCartCount() {
    const total = state.cart.reduce((s, i) => s + i.qty, 0);
    if (!cartCount) return;
    cartCount.textContent = total;
    total > 0 ? cartCount.classList.add('visible') : cartCount.classList.remove('visible');
  }

  function renderCart() {
    const empty    = $('#cartEmpty');
    const items    = $('#cartItems');
    const footer   = $('#cartFooter');
    const totalEl  = $('#cartTotal');
    if (!items) return;

    if (state.cart.length === 0) {
      empty  && (empty.style.display  = '');
      items.innerHTML = '';
      footer && (footer.style.display = 'none');
      return;
    }

    empty  && (empty.style.display  = 'none');
    footer && (footer.style.display = '');

    items.innerHTML = state.cart.map(item => `
      <div class="cart-item" data-id="${item.id}">
        <img src="${item.img}" alt="${item.name}" class="cart-item-img" />
        <div class="cart-item-info">
          <p class="cart-item-name">${item.name}</p>
          <p class="cart-item-price">${item.price}</p>
          <button class="cart-item-remove" data-remove="${item.id}">Remove</button>
        </div>
      </div>
    `).join('');

    // Total
    const total = state.cart.reduce((s, i) => s + (i.rawPrice * i.qty), 0);
    if (totalEl) totalEl.textContent = `PKR ${total.toLocaleString('en-PK')}`;

    // Remove buttons
    $$('[data-remove]', items).forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.remove;
        state.cart = state.cart.filter(i => i.id !== id);
        saveCart();
        renderCart();
        updateCartCount();
      });
    });
  }

  window.addToCart = function(id, name, price, rawPrice, img) {
    const existing = state.cart.find(i => i.id === id);
    if (existing) {
      existing.qty++;
    } else {
      state.cart.push({ id, name, price, rawPrice, img, qty: 1 });
    }
    saveCart();
    renderCart();
    updateCartCount();
    openCart();
  };

  // Init
  renderCart();
  updateCartCount();
})();

/* ════════════════════════════════════════════════════════
   WISHLIST
════════════════════════════════════════════════════════ */
(function initWishlist() {
  function updateWishlistBtns() {
    $$('.wishlist-btn').forEach(btn => {
      const id = btn.dataset.id;
      if (state.wishlist.includes(id)) {
        btn.classList.add('active');
        btn.setAttribute('aria-label', 'Remove from wishlist');
      } else {
        btn.classList.remove('active');
        btn.setAttribute('aria-label', 'Add to wishlist');
      }
    });
  }

  document.addEventListener('click', e => {
    const btn = e.target.closest('.wishlist-btn');
    if (!btn) return;
    const id = btn.dataset.id;
    if (!id) return;
    if (state.wishlist.includes(id)) {
      state.wishlist = state.wishlist.filter(w => w !== id);
      showToast('Removed from wishlist');
    } else {
      state.wishlist.push(id);
      showToast('Added to wishlist');
    }
    saveWishlist();
    updateWishlistBtns();
  });

  updateWishlistBtns();
})();

/* ════════════════════════════════════════════════════════
   QUICK ADD
════════════════════════════════════════════════════════ */
(function initQuickAdd() {
  // Product data map (id → details)
  const products = {
    '1':  { name: 'Rose Garden Embroidered Lawn', price: 'PKR 8,500',  raw: 8500,  img: 'https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=120&q=60' },
    '2':  { name: 'Midnight Chiffon Formal Set',  price: 'PKR 15,400', raw: 15400, img: 'https://images.unsplash.com/photo-1614251056798-0a63eda2bb25?w=120&q=60' },
    '3':  { name: 'Zari Jacquard Co-ord Set',     price: 'PKR 19,800', raw: 19800, img: 'https://images.unsplash.com/photo-1609505848912-b7c3b9a4d34d?w=120&q=60' },
    '4':  { name: 'Gulbahar Hand-Embroidered Kurti', price: 'PKR 6,800', raw: 6800, img: 'https://images.unsplash.com/photo-1617019114583-affb34d1b3cd?w=120&q=60' },
    '5':  { name: 'Gulabi Lawn 3-Piece Unstitched', price: 'PKR 7,200', raw: 7200,  img: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=120&q=60' },
    '6':  { name: 'Shahtoot Silk Dupatta Set',    price: 'PKR 24,500', raw: 24500, img: 'https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=120&q=60' },
    '7':  { name: 'Nargis Organza Party Wear',    price: 'PKR 32,000', raw: 32000, img: 'https://images.unsplash.com/photo-1617019114583-affb34d1b3cd?w=120&q=60' },
    '8':  { name: 'Jasmine Printed Casual Kurta', price: 'PKR 4,200',  raw: 4200,  img: 'https://images.unsplash.com/photo-1614251056798-0a63eda2bb25?w=120&q=60' },
    'look1': { name: 'Zari Silk Dupatta',         price: 'PKR 6,500',  raw: 6500,  img: 'https://images.unsplash.com/photo-1583391733956-6c78276477e2?w=120&q=60' },
    'look2': { name: 'Gulabi Embroidered Suit',   price: 'PKR 18,000', raw: 18000, img: 'https://images.unsplash.com/photo-1610030469983-98e550d6193c?w=120&q=60' },
  };

  document.addEventListener('click', e => {
    const btn = e.target.closest('.quick-add, .look-product-add');
    if (!btn) return;
    const id = btn.dataset.id;
    if (!id || !products[id]) return;
    const p = products[id];
    window.addToCart(id, p.name, p.price, p.raw, p.img);
    showToast(`${p.name} added to bag`);
  });
})();

/* ════════════════════════════════════════════════════════
   NEWSLETTER
════════════════════════════════════════════════════════ */
(function initNewsletter() {
  const form  = $('#newsletterForm');
  const email = $('#newsletterEmail');
  if (!form) return;

  form.addEventListener('submit', e => {
    e.preventDefault();
    const val = email.value.trim();
    if (!val) return;
    showToast('Thank you for subscribing to Salman Collection!');
    email.value = '';
  });
})();

/* ════════════════════════════════════════════════════════
   COLOR DOT INTERACTIONS
════════════════════════════════════════════════════════ */
(function initColorDots() {
  document.addEventListener('click', e => {
    const dot = e.target.closest('.color-dot');
    if (!dot) return;
    const siblings = $$('.color-dot', dot.closest('.product-colors'));
    siblings.forEach(d => d.classList.remove('active'));
    dot.classList.add('active');
  });
})();

/* ════════════════════════════════════════════════════════
   TOAST NOTIFICATION
════════════════════════════════════════════════════════ */
let toastTimer = null;
function showToast(msg) {
  const toast = $('#toast');
  if (!toast) return;
  toast.textContent = msg;
  toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
}

/* ════════════════════════════════════════════════════════
   SCROLL REVEAL
════════════════════════════════════════════════════════ */
(function initScrollReveal() {
  const targets = [
    '.section-header',
    '.collection-card',
    '.product-card',
    '.look-right',
    '.story-text-col',
    '.story-img-col',
    '.stat-item',
    '.insta-item',
    '.newsletter-inner',
    '.footer-brand',
    '.footer-links-group',
  ];

  const revealEls = targets.flatMap(sel => $$(sel));
  revealEls.forEach((el, i) => {
    el.classList.add('reveal');
    // Stagger siblings in same grid
    const parent = el.parentElement;
    const siblings = $$('.reveal', parent);
    const localIdx = siblings.indexOf(el);
    if (localIdx > 0) {
      el.style.transitionDelay = `${Math.min(localIdx * 80, 320)}ms`;
    }
  });

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('visible');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1, rootMargin: '0px 0px -60px 0px' });

  revealEls.forEach(el => observer.observe(el));
})();

/* ════════════════════════════════════════════════════════
   LOOK HOTSPOT — ensure touch support
════════════════════════════════════════════════════════ */
(function initHotspots() {
  $$('.look-hotspot').forEach(hotspot => {
    hotspot.addEventListener('click', () => {
      const tooltip = $('.hotspot-tooltip', hotspot);
      if (!tooltip) return;
      const visible = tooltip.style.opacity === '1';
      tooltip.style.opacity = visible ? '0' : '1';
    });
  });
})();

const looks = [
  {
    image: "./public/look1.webp",
    name: "SEHRZAT",
    price: "Rs 7,112",
    cardImage: "./public/look1.webp"
  },
  {
    image: "./public/look2.webp",
    name: "MAHROSH",
    price: "Rs 8,450",
    cardImage: "./public/look2.webp"
   
  },
];

let current = 0;

const mainImage = document.querySelector('.main-look img');
const cardImage = document.querySelector('.product-card img');
const productName = document.querySelector('.product-info h4');
const productPrice = document.querySelector('.product-info p');

function updateSlide() {
  mainImage.src = looks[current].image;
  cardImage.src = looks[current].cardImage;
  productName.textContent = looks[current].name;
  productPrice.textContent = looks[current].price;
}

document.querySelector('.next').addEventListener('click', () => {
  current++;
  if (current >= looks.length) current = 0;
  updateSlide();
});

document.querySelector('.prev').addEventListener('click', () => {
  current--;
  if (current < 0) current = looks.length - 1;
  updateSlide();
});

updateSlide();
/* ════════════════════════════════════════════════════════
   LAZY IMAGE FADE-IN
════════════════════════════════════════════════════════ */
(function initImgFade() {
  const imgs = $$('img[loading="lazy"]');
  imgs.forEach(img => {
    img.style.opacity = '0';
    img.style.transition = 'opacity 0.5s ease';
    if (img.complete) {
      img.style.opacity = '1';
    } else {
      img.addEventListener('load', () => { img.style.opacity = '1'; });
    }
  });
})();

/* ════════════════════════════════════════════════════════
   SMOOTH ANCHOR SCROLL
════════════════════════════════════════════════════════ */
(function initSmoothScroll() {
  document.addEventListener('click', e => {
    const link = e.target.closest('a[href^="#"]');
    if (!link) return;
    const target = $(link.getAttribute('href'));
    if (!target) return;
    e.preventDefault();
    const headerH = parseInt(getComputedStyle(document.documentElement).getPropertyValue('--header-h')) || 76;
    const offset  = target.getBoundingClientRect().top + window.scrollY - headerH - 20;
    window.scrollTo({ top: offset, behavior: 'smooth' });
  });
})();
